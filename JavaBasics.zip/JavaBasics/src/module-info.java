/**
 * 
 */
/**
 * @author Shane Hagan
 *
 */
module JavaBasics {
}