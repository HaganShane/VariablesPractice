package com.hagan.javabasics;

public class Welcome {
	
	// This program prints Welcome to Java!
	public static void main(String[] args) {
		System.out.println("Welcome to Java!");

	}

}
